﻿namespace InternRegistrationForm.Models
{
    public class RegistrationViewModel
    {
        public InternsModel Intern { get; set; }

        public TermDatesModel TermDates { get; set; }

    }
}
