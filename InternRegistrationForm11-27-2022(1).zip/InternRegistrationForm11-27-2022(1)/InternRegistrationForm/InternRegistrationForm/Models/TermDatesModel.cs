﻿namespace InternRegistrationForm.Models
{
    public class TermDatesModel
    {
        public int Id { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate{ get; set; }
        public string Track { get; set; }
    }
}
