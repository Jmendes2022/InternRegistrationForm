﻿namespace InternRegistrationForm.Models
{
    public class ReportViewModel
    {
        public List<InternsModel> Interns { get; set; }
        public string ReportName { get; set; }

    }
}
